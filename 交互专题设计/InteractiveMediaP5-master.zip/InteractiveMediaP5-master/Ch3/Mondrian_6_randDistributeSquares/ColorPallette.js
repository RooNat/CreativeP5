// color pallette
var ColorPallette = new Array(3);

function InitColorPallette()
{
  ColorPallette[0] = color(180,80,90);
  ColorPallette[1] = color(10,50,120);
  ColorPallette[2] = color(190,120,40);
}