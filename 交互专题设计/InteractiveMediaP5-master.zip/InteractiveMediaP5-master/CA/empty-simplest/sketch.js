// 函数setup() ：准备阶段
function setup() {
	createCanvas(400,300);
}

// 函数draw()：作画阶段
function draw() {
	fill(255);// 填充白色
	ellipse(100,100,200,200); // 画圆形
}