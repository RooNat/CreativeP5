// base line
var L;
var LD;
var VtNum = 512;
var LineWd = 2.0;
var LLength = 0;

// dynamic line params
var DAmp;
var DFreq;
var DPhase;
