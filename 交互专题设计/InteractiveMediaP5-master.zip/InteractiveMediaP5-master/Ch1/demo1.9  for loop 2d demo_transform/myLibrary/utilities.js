

function GetTimeNow()
{
	var tNow = millis()/1000;
	return tNow;
}

