// 函数setup() ：准备阶段
function setup() {
	createCanvas(400,300);
}

// 函数draw()：作画阶段
function draw() {
	fill(255);// 填充白色
	ellipse(100,100,200,200); // 画圆形

	// case 1
	if (mouseX>100)
	{
		// A
	}
	else
	{
		// B
	}

	// case 2
	if(tiaojian1)
	{
		// A
	}
	// B

	// case 3
	if(tiaojian1){
		// A
	}
	else if(tiaojian2){
		// B
	}

	// case 4
	if(tiaojian1){
		// A
	}
	if(tiaojian2){
		// B
	}


	if(a)
	{

	}
	else if(b)
	{

	}
	else if(c)
	{

	}
	else
	{

	}

	if(d)
	{
		
	}



}