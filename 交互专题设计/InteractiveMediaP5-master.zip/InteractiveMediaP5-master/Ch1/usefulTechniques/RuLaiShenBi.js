/* 如来神笔 */

function RuLaiShenBi()
{
	triangle(-50,25,50,25,-100,-25);
}
