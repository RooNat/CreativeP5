function setup() {
	createCanvas(640,480);
}
function draw() {
	fill(255);
	ellipse(320,240,200,200);	
	ellipse(280,240,50,50);
	ellipse(360,240,50,50); 	
	ellipse(320,300,80,40);	
	fill(0);	
	ellipse(280,240,20,20);	
	ellipse(360,240,20,20);	
	line(260,180,260,100);
	line(280,180,280,100);
	line(300,180,300,100);
	line(320,180,320,100);
	line(340,180,340,100);
	line(360,180,360,100);
	line(380,180,380,100);
}