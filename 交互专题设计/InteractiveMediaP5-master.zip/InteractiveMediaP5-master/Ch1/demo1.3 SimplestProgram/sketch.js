// 函数setup() ：准备阶段
function setup() {
	createCanvas(640,480);
}

// 函数draw()：作画阶段
function draw() {
	fill(255);// 填充白色
	ellipse(320,240,100,100); // 画圆形
}