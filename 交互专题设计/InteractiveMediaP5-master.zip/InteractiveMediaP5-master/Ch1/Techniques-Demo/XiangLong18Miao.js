/*-----------  降龙十八描 ----------*/

function Tech0()
{
	fill(255);
	rect(-50,-50,100,100);
	fill(0);
	ellipse(0,0,100,100);
}

function Tech1(x,y)
{
	fill(255);
	ellipse(0,0,100,100);
	fill(0);
	ellipse(0,0,80,80);
}